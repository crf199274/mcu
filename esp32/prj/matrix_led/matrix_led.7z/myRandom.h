#ifndef __myRandom_H
#define __myRandom_H

#include "arduino.h"

uint32_t getARandom(uint32_t start,uint32_t end);

#endif
