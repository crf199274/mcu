#ifndef  _Output_H
#define _Output_H

#include "stm32f10x.h"

extern float pitch,roll,yaw;
extern int gyrox,gyroy,gyroz;
extern int aacx,aacy,aacz;

extern int Encoder_L,Encoder_R;

#endif
